package com.example.examenib

class Usuario {
    companion object{
        var nombre: String = ""
    }
}