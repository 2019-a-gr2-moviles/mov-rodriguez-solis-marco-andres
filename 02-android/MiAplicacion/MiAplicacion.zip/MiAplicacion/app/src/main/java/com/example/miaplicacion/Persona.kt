package com.example.miaplicacion

class Persona(var nombre: String, var cedula: String) {

}